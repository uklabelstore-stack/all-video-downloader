(() => {
const $ = s => document.querySelector(s);
const workspace = $('.workspace'); if (!workspace) return;
const action = workspace.dataset.action, input = $('#tool-input'), output = $('#tool-output'), extras = $('#extra-controls'), downloadBox = $('#download-output');
const addInput = (id,label,placeholder='',type='text',value='') => { const wrap=document.createElement('div'); const l=document.createElement('label');l.htmlFor=id;l.textContent=label;const el=document.createElement('input');el.id=id;el.type=type;el.placeholder=placeholder;el.value=value;wrap.append(l,el);extras.append(wrap);return el; };
const addSelect = (id,label,options) => { const l=document.createElement('label');l.htmlFor=id;l.textContent=label;const s=document.createElement('select');s.id=id;options.forEach(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;s.append(o)});extras.append(l,s);return s; };
const addFile = (accept='*/*') => { const f=addInput('tool-file','Choose file','', 'file');f.accept=accept;return f; };
const result = (v) => { output.textContent=typeof v==='string'?v:JSON.stringify(v,null,2); downloadBox.innerHTML=''; if(typeof v==='string' && v.length>0){const b=document.createElement('button');b.className='secondary small';b.textContent='Download result as .txt';b.onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([v],{type:'text/plain;charset=utf-8'}));a.download='vdownloader-result.txt';a.click();URL.revokeObjectURL(a.href)};downloadBox.append(b)} };
const text = () => input.value || '';
const makeImg = async (mode) => {const f=$('#tool-file')?.files?.[0];if(!f)throw Error('Pehle image file select karein.');const url=URL.createObjectURL(f);try{const img=new Image();img.src=url;await img.decode();let w=img.naturalWidth,h=img.naturalHeight;if(mode==='resize'){w=Math.max(1,parseInt($('#width').value)||w);h=Math.max(1,parseInt($('#height').value)||h)}const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').drawImage(img,0,0,w,h);const mime=$('#format')?.value|| (mode==='compress'?'image/jpeg':'image/png');const quality=mode==='compress'?(Number($('#quality')?.value||80)/100):.92;const blob=await new Promise(res=>c.toBlob(res,mime,quality));if(!blob)throw Error('Browser is format ko export nahi kar saka.');const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='vdownloader-image.'+({'image/png':'png','image/jpeg':'jpg','image/webp':'webp'}[mime]||'png');a.textContent='Download processed image';a.className='open-tool';downloadBox.append(a);result(`Done. Original: ${img.naturalWidth}×${img.naturalHeight}\nOutput: ${w}×${h}\nOutput size: ${blob.size.toLocaleString()} bytes`);}finally{URL.revokeObjectURL(url)}};
function setup(){switch(action){
case 'video-downloader':input.placeholder='Paste a supported video URL (YouTube, TikTok, Instagram, Vimeo, etc.)';break;
case 'case-converter':addSelect('case','Conversion',[['upper','UPPERCASE'],['lower','lowercase'],['title','Title Case'],['sentence','Sentence case']]);break;
case 'reverse-text':addSelect('reverse-mode','Reverse mode',[['chars','Characters'],['words','Word order']]);break;
case 'url-codec':addSelect('codec','Mode',[['encode','Encode'],['decode','Decode']]);break;
case 'base64':addSelect('b64mode','Mode',[['encode','Encode'],['decode','Decode']]);break;
case 'json':addSelect('jsonmode','Mode',[['pretty','Format JSON'],['minify','Minify JSON']]);break;
case 'html-escape':addSelect('htmlmode','Mode',[['escape','Escape HTML'],['unescape','Unescape HTML']]);break;
case 'password':addInput('length','Password length','16','number','16');addSelect('charset','Character set',[['all','Letters + numbers + symbols'],['alnum','Letters + numbers'],['letters','Letters only']]);break;
case 'hash':addSelect('hashmode','Algorithm',[['SHA-256','SHA-256'],['SHA-1','SHA-1'],['SHA-512','SHA-512']]);break;
case 'timestamp':addSelect('tsmode','Mode',[['to-date','Timestamp to date'],['to-ts','Date to timestamp']]);break;
case 'lorem':addInput('count','Paragraphs','3','number','3');break;
case 'text-diff':addInput('compare','Second text block','Paste comparison text');break;
case 'regex':addInput('pattern','Regular expression','e.g. \\bcat\\b');addSelect('flags','Flags',[['g','Global'],['gi','Global + case-insensitive'],['i','Case-insensitive']]);break;
case 'meta-tags':addInput('metatitle','Page title','Your page title');addInput('description','Meta description','Up to about 160 characters');addInput('canonical','Canonical URL','https://example.com/page');break;
case 'robots':addInput('site','Sitemap URL','https://example.com/sitemap.xml');addSelect('crawl','Search crawler access',[['all','Allow all pages'],['block','Block all pages']]);break;
case 'sitemap':addInput('domain','Base domain','https://example.com');break;
case 'keyword-density':addInput('keyword','Keyword to check','keyword');break;
case 'image-resize':addFile('image/*');addInput('width','Width (px)','800','number');addInput('height','Height (px)','600','number');break;
case 'image-convert':case 'image-compress':addFile('image/*');addSelect('format','Output format',[['image/png','PNG'],['image/jpeg','JPEG'],['image/webp','WebP']]);if(action==='image-compress')addInput('quality','Quality (1–100)','80','number','80');break;
case 'image-base64':addFile('image/*');break;
case 'color':addInput('hex','HEX color','#635bff');break;
case 'percentage':addInput('percent','Percentage','15','number','15');addInput('number','Number','200','number','200');break;
case 'average':break;
case 'unit-convert':addSelect('unitmode','Conversion',[['km-mi','Kilometres → miles'],['mi-km','Miles → kilometres'],['kg-lb','Kilograms → pounds'],['lb-kg','Pounds → kilograms'],['cm-in','Centimetres → inches'],['in-cm','Inches → centimetres']]);break;
case 'csv-json':case 'json-csv':break;
case 'word-frequency':addInput('top','Top words','20','number','20');break;
case 'email-validator':case 'phone-cleaner':case 'binary':addSelect('binmode','Mode',[['encode','Encode'],['decode','Decode']]);break;
case 'number-base':addSelect('basemode','Mode',[['10-2','Decimal → Binary'],['10-8','Decimal → Octal'],['10-16','Decimal → Hex'],['2-10','Binary → Decimal'],['16-10','Hex → Decimal']]);break;
case 'random-number':addInput('min','Minimum','1','number','1');addInput('max','Maximum','100','number','100');break;
case 'date-diff':addInput('date1','Start date','','date');addInput('date2','End date','','date');break;
case 'aspect-ratio':addInput('width','Width','1920','number','1920');addInput('height','Height','1080','number','1080');break;
case 'clip-title':addInput('platform','Platform','YouTube Shorts, TikTok…','text','Short video');break;
case 'video-description':addInput('channel','Channel or brand','Your channel');addInput('cta','Call to action','Subscribe / follow');break;
case 'subtitle-cleaner':break;
case 'prompt-builder':addSelect('prompttype','Prompt type',[['image','Image generation'],['video','Video generation'],['writing','Writing'],['marketing','Marketing copy']]);addInput('style','Style / mood','cinematic, clean, professional');break;
case 'tags':break;
case 'pdf-planner':addInput('pages','Total pages','100','number','100');addInput('ranges','Page ranges','1-10, 11-20');break;
case 'audio-info':break;
}}
setup();
$('#clear-tool').onclick=()=>{input.value='';extras.querySelectorAll('input').forEach(e=>{if(e.type==='file')e.value='';else if(e.type!=='date')e.value=''});result('Your result will appear here.')};
$('#copy-output').onclick=async()=>{try{await navigator.clipboard.writeText(output.textContent);$('#copy-output').textContent='Copied!';setTimeout(()=>$('#copy-output').textContent='Copy result',1200)}catch(e){result('Clipboard access blocked. Select and copy the result manually.')}};
$('#run-tool').onclick=async()=>{try{const s=text();let v;switch(action){
case 'video-downloader':{const resp=await fetch('/download',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:s.trim()})});const data=await resp.json();if(!resp.ok)throw Error(data.error||'Video details could not be fetched.');v=`Title: ${data.title}\nUploader: ${data.uploader||'Unknown'}\nDuration: ${data.duration??'Unknown'} seconds\nSource: ${data.webpage_url}\n\nAvailable formats:\n${(data.formats||[]).map(f=>`${f.format_id} | ${f.ext||'?'} | ${f.resolution||'unknown resolution'} | video:${f.has_video} audio:${f.has_audio} | size:${f.filesize||'unknown'}`).join('\n')}\n\n${data.notice||''}`;if(data.thumbnail){const im=document.createElement('img');im.src=data.thumbnail;im.alt='Video thumbnail';im.style.maxWidth='100%';im.style.borderRadius='8px';downloadBox.append(im)}break;}
case 'word-counter':v=`Words: ${(s.trim().match(/\S+/g)||[]).length}\nCharacters: ${s.length}\nCharacters (no spaces): ${s.replace(/\s/g,'').length}\nSentences: ${(s.match(/[.!?]+(?=\s|$)/g)||[]).length}\nParagraphs: ${s.trim()?s.trim().split(/\n\s*\n/).length:0}`;break;
case 'case-converter':v=$('#case').value==='upper'?s.toUpperCase():$('#case').value==='lower'?s.toLowerCase():$('#case').value==='title'?s.toLowerCase().replace(/\b\w/g,c=>c.toUpperCase()):s.toLowerCase().replace(/(^\s*\w|[.!?]\s+\w)/g,c=>c.toUpperCase());break;
case 'dedupe-lines':v=[...new Set(s.split(/\r?\n/))].join('\n');break;case 'sort-lines':v=s.split(/\r?\n/).sort((a,b)=>a.localeCompare(b)).join('\n');break;
case 'reverse-text':v=$('#reverse-mode').value==='words'?s.trim().split(/\s+/).reverse().join(' '):Array.from(s).reverse().join('');break;
case 'slug':v=s.toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');break;
case 'url-codec':v=$('#codec').value==='encode'?encodeURIComponent(s):decodeURIComponent(s);break;
case 'base64':v=$('#b64mode').value==='encode'?btoa(unescape(encodeURIComponent(s))):decodeURIComponent(escape(atob(s.trim())));break;
case 'json':{const j=JSON.parse(s);v=$('#jsonmode').value==='pretty'?JSON.stringify(j,null,2):JSON.stringify(j);break}
case 'html-escape':if($('#htmlmode').value==='escape')v=s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');else{const d=document.createElement('textarea');d.innerHTML=s;v=d.value}break;
case 'url-parser':{const u=new URL(s);v={protocol:u.protocol,hostname:u.hostname,port:u.port||'(default)',pathname:u.pathname,query:Object.fromEntries(u.searchParams.entries()),hash:u.hash};break}
case 'password':{const n=Math.min(256,Math.max(4,parseInt($('#length').value)||16));const cs=$('#charset').value==='letters'?stringLetters():$('#charset').value==='alnum'?stringLetters()+'0123456789':stringLetters()+'0123456789!@#$%^&*()-_=+[]{}?';v=Array.from(crypto.getRandomValues(new Uint32Array(n)),x=>cs[x%cs.length]).join('');break}
case 'uuid':v=crypto.randomUUID?crypto.randomUUID():'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{const r=crypto.getRandomValues(new Uint8Array(1))[0]%16;return(c==='x'?r:(r&3|8)).toString(16)});break;
case 'hash':{const b=await crypto.subtle.digest($('#hashmode').value,new TextEncoder().encode(s));v=Array.from(new Uint8Array(b),b=>b.toString(16).padStart(2,'0')).join('');break}
case 'timestamp':{if($('#tsmode').value==='to-date'){const n=Number(s);const d=new Date(Math.abs(n)<1e12?n*1000:n);if(isNaN(d))throw Error('Valid timestamp dein.');v=d.toISOString()}else{const d=new Date(s);if(isNaN(d))throw Error('Valid date dein.');v=String(Math.floor(d.getTime()/1000))}break}
case 'lorem':{const para='Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Cras mattis consectetur purus sit amet fermentum. ';v=Array.from({length:Math.min(30,Math.max(1,Number($('#count').value)||3))},()=>para.repeat(2).trim()).join('\n\n');break}
case 'char-frequency':{const m={};for(const c of s)m[c]=(m[c]||0)+1;v=Object.entries(m).sort((a,b)=>b[1]-a[1]).map(([c,n])=>`${JSON.stringify(c)}: ${n}`).join('\n');break}
case 'line-counter':v=`Total lines: ${s? s.split(/\r?\n/).length:0}\nBlank lines: ${s.split(/\r?\n/).filter(x=>!x.trim()).length}`;break;
case 'text-diff':{const a=s.split(/\r?\n/),b=$('#compare').value.split(/\r?\n/),n=Math.max(a.length,b.length);v=Array.from({length:n},(_,i)=>a[i]===b[i]?`  ${a[i]??''}`:`- ${a[i]??''}\n+ ${b[i]??''}`).join('\n');break}
case 'regex':{const re=new RegExp($('#pattern').value,$('#flags').value);v=Array.from(s.matchAll(new RegExp(re.source,re.flags.includes('g')?re.flags:re.flags+'g'))).map(m=>`${m[0]} (index ${m.index})`).join('\n')||'No matches';break}
case 'markdown':v=s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/^### (.*)$/gm,'$1\n'+ '='.repeat(5)).replace(/^## (.*)$/gm,'$1\n'+'-'.repeat(5)).replace(/^# (.*)$/gm,'$1\n'+'='.repeat(10)).replace(/\*\*(.*?)\*\*/g,'$1').replace(/\*(.*?)\*/g,'$1').replace(/`(.*?)`/g,'$1').replace(/\[(.*?)\]\((.*?)\)/g,'$1 ($2)');break;
case 'meta-tags':v=`<title>${esc($('#metatitle').value)}</title>\n<meta name="description" content="${esc($('#description').value)}">\n<link rel="canonical" href="${esc($('#canonical').value)}">\n<meta property="og:title" content="${esc($('#metatitle').value)}">\n<meta property="og:description" content="${esc($('#description').value)}">`;break;
case 'robots':v=`User-agent: *\n${$('#crawl').value==='all'?'Allow: /':'Disallow: /'}\nSitemap: ${$('#site').value}`;break;
case 'sitemap':{const d=$('#domain').value.replace(/\/$/,'');const urls=s.split(/\r?\n/).map(x=>x.trim()).filter(Boolean).map(x=>/^https?:\/\//i.test(x)?x:d+'/'+x.replace(/^\//,''));v='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+urls.map(u=>`  <url><loc>${esc(u)}</loc></url>`).join('\n')+'\n</urlset>';break}
case 'keyword-density':{const k=$('#keyword').value.trim().toLowerCase();const words=s.toLowerCase().match(/[\p{L}\p{N}]+/gu)||[];const n=k?words.filter(w=>w===k).length:0;v=`Keyword: ${k}\nOccurrences: ${n}\nTotal words: ${words.length}\nDensity: ${words.length?(n/words.length*100).toFixed(2):'0.00'}%`;break}
case 'reading-time':{const n=(s.trim().match(/\S+/g)||[]).length;v=`Words: ${n}\nEstimated reading time: ${Math.max(1,Math.ceil(n/225))} minute(s) at 225 words/minute.`;break}
case 'image-resize':await makeImg('resize');return;case 'image-convert':await makeImg('convert');return;case 'image-compress':await makeImg('compress');return;
case 'image-base64':{const f=$('#tool-file').files[0];if(!f)throw Error('Image select karein.');v=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(f)});break}
case 'color':{let h=$('#hex').value.replace('#','');if(!/^[0-9a-f]{3}([0-9a-f]{3})?$/i.test(h))throw Error('HEX color #fff ya #ffffff format mein dein.');if(h.length===3)h=h.split('').map(c=>c+c).join('');const n=parseInt(h,16);v={hex:'#'+h.toUpperCase(),rgb:`rgb(${n>>16}, ${(n>>8)&255}, ${n&255})`,red:n>>16,green:(n>>8)&255,blue:n&255};break}
case 'percentage':v=(Number($('#percent').value)*Number($('#number').value)/100).toString();break;
case 'average':{const ns=s.split(/[\s,;]+/).filter(Boolean).map(Number);if(!ns.length||ns.some(Number.isNaN))throw Error('Numbers comma ya spaces se separate karein.');v=`Count: ${ns.length}\nSum: ${ns.reduce((a,b)=>a+b,0)}\nAverage: ${ns.reduce((a,b)=>a+b,0)/ns.length}`;break}
case 'unit-convert':{const n=Number(s);const f={'km-mi':.621371,'mi-km':1.609344,'kg-lb':2.20462262,'lb-kg':.45359237,'cm-in':.393700787,'in-cm':2.54}[$('#unitmode').value];v=String(n*f);break}
case 'csv-json':{const rows=s.trim().split(/\r?\n/).map(line=>line.split(',').map(x=>x.trim().replace(/^"|"$/g,'')));if(rows.length<2)throw Error('Header aur kam az kam ek data row dein.');v=JSON.stringify(rows.slice(1).map(r=>Object.fromEntries(rows[0].map((k,i)=>[k,r[i]??'']))),null,2);break}
case 'json-csv':{const j=JSON.parse(s);if(!Array.isArray(j)||!j.length||typeof j[0]!=='object')throw Error('JSON objects ka non-empty array dein.');const keys=[...new Set(j.flatMap(Object.keys))];v=[keys.join(','),...j.map(o=>keys.map(k=>csvCell(o[k])).join(','))].join('\n');break}
case 'html-minify':v=s.replace(/>\s+</g,'><').replace(/\s{2,}/g,' ').trim();break;case 'css-minify':v=s.replace(/\/\*[\s\S]*?\*\//g,'').replace(/\s*([{}:;,])\s*/g,'$1').replace(/;}/g,'}').trim();break;case 'js-minify':v=s.replace(/\/\*[\s\S]*?\*\//g,'').replace(/(^|\s)\/\/[^\n]*/g,'').replace(/\s{2,}/g,' ').trim();break;
case 'word-frequency':{const ws=s.toLowerCase().match(/[\p{L}\p{N}']+/gu)||[],m={};ws.forEach(w=>m[w]=(m[w]||0)+1);v=Object.entries(m).sort((a,b)=>b[1]-a[1]).slice(0,Math.max(1,Number($('#top').value)||20)).map(([w,n])=>`${w}: ${n}`).join('\n');break}
case 'email-validator':{const val=s.trim();v=`${/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)?'Looks like a valid email format':'Invalid email format'}\nNote: syntax check only; mailbox existence is not verified.`;break}
case 'phone-cleaner':v=s.replace(/[^+\d]/g,'');break;
case 'binary':if($('#binmode').value==='encode')v=Array.from(new TextEncoder().encode(s),b=>b.toString(2).padStart(8,'0')).join(' ');else{const parts=s.trim().split(/[\s,]+/);v=new TextDecoder().decode(new Uint8Array(parts.map(p=>{if(!/^[01]{1,8}$/.test(p))throw Error('Binary bytes 0-1 ke 8 bits mein dein.');return parseInt(p,2)})));}break;
case 'number-base':{const mode=$('#basemode').value;const from=mode.startsWith('10-')?10:mode.startsWith('2-')?2:16,to=Number(mode.split('-')[1]);const n=parseInt(s.trim(),from);if(!Number.isFinite(n))throw Error('Valid integer dein.');v=n.toString(to).toUpperCase();break}
case 'random-number':{const a=Math.ceil(Number($('#min').value)),b=Math.floor(Number($('#max').value));if(b<a)throw Error('Maximum, minimum se bara ya barabar ho.');v=String(a+Math.floor(Math.random()*(b-a+1)));break}
case 'date-diff':{const a=new Date($('#date1').value),b=new Date($('#date2').value);if(isNaN(a)||isNaN(b))throw Error('Dono dates select karein.');v=`Difference: ${Math.round(Math.abs(b-a)/86400000)} days`;break}
case 'aspect-ratio':{const w=Number($('#width').value),h=Number($('#height').value);if(w<=0||h<=0)throw Error('Width aur height positive hon.');const gcd=(a,b)=>b?gcd(b,a%b):a;v=`Ratio: ${w/gcd(w,h)}:${h/gcd(w,h)}\n16:9 match: ${(w/h).toFixed(4)} (target 1.7778)\n9:16 match: ${(w/h).toFixed(4)} (target 0.5625)\n4:3 match: ${(w/h).toFixed(4)} (target 1.3333)`;break}
case 'clip-title':{const topic=s.trim()||'Your topic';const p=$('#platform').value;v=[`You Won't Believe This: ${topic}`,`The Best Part of ${topic} (Wait for It!)`,`3 Things to Know About ${topic}`,`${topic}: Quick Breakdown`,`Watch Until the End — ${topic}`].map(x=>`${x} [${p}]`).join('\n');break}
case 'video-description':v=`${s.trim()||'Video title'}\n\nIn this video, we cover the key points, useful tips, and highlights.\n\n${$('#cta').value||'Follow for more'}\n\nChannel: ${$('#channel').value||'Your channel'}\n\n#shorts #video #tips`;break;
case 'subtitle-cleaner':v=s.replace(/^\s*\d+\s*$/gm,'').replace(/^\s*(?:\d{2}:\d{2}:\d{2}[,.]\d{3}\s*-->.*|WEBVTT.*)$/gm,'').replace(/<[^>]+>/g,'').replace(/^\s*$/gm,'').trim();break;
case 'prompt-builder':{const type=$('#prompttype').value,style=$('#style').value;v=type==='image'?`Create a high-quality image about: ${s}\nStyle: ${style}\nComposition: clear subject, intentional lighting, balanced framing, high detail. Avoid unwanted text, logos and watermarks.`:type==='video'?`Create a video about: ${s}\nVisual style: ${style}\nInclude: subject, setting, camera movement, lighting, action progression and consistent visual continuity.\nOutput: specify aspect ratio and duration before generation.`:type==='marketing'?`Write persuasive but accurate marketing copy for: ${s}\nTone: ${style}\nAudience, benefits, proof points and one clear call to action. Do not invent claims.`:`Write about: ${s}\nStyle: ${style}\nStructure: clear title, concise introduction, useful sections, examples and a short conclusion. Do not invent facts or sources.`;break}
case 'tags':v=[...new Set((s.toLowerCase().match(/[\p{L}\p{N}]+/gu)||[]).filter(w=>w.length>2))].slice(0,30).map(w=>'#'+w).join(' ');break;
case 'pdf-planner':{const n=Math.max(1,Number($('#pages').value)||1);v=`Total pages: ${n}\nSuggested split ranges: ${$('#ranges').value||`1-${n}`}\nNote: this tool plans page ranges only. It does not edit or split PDF files.`;break}
case 'audio-info':v='MP3: widely compatible, lossy.\nWAV: typically uncompressed PCM, large files.\nAAC/M4A: efficient lossy audio.\nFLAC: lossless compression.\nOGG: open container commonly used with Vorbis/Opus.\nThis helper provides guidance only; it does not encode audio.';break;
default:v='This catalog entry is a guide/variant. The related core tool may be available via search. Advanced processing may require an external API.';
}result(v)}catch(e){result('Error: '+(e.message||String(e)))} };
function stringLetters(){return 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'}function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}function csvCell(x){let s=x==null?'':typeof x==='object'?JSON.stringify(x):String(x);return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s}
})();
