# VDownloader — Flask/Vercel all-in-one tools

## Included
- Flask app with a top-level `app` object for Vercel Python.
- Existing-style `/download` metadata endpoint powered by `yt-dlp` for a list of supported video platforms.
- 55 browser-side core tool engines across text, developer, SEO, image, video-helper, PDF-helper, AI-prompt and everyday utility categories.
- Searchable directory with 10,000 catalog URLs generated from reusable tool engines.
- SEO title/description, `/robots.txt`, `/sitemap.xml`, and About/Privacy/Terms/Contact pages.
- Responsive layout, tool output copy and text result download.

## Deploy to Vercel
1. Upload this folder to a GitHub repository.
2. Import the repository in Vercel.
3. Add environment variable `SITE_URL` with your canonical URL, e.g. `https://vdownloder.xyz` (correct spelling/domain as registered).
4. Deploy.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python main.py
```
Open `http://127.0.0.1:5000`.

## Important implementation notes
- The 10,000 URLs are tool/workflow catalog pages generated from reusable engines. They are not 10,000 independent algorithms or 10,000 separate AI models. The directory states this clearly.
- 55 core tool engines are implemented in browser JavaScript. Image operations run locally using Canvas; most text utilities run locally. The PDF and audio entries are planning/guidance helpers, not full PDF editing/audio transcoding.
- AI prompt generation is template-based. Actual AI image/video/text generation needs a provider API and billing/quotas.
- `/download` extracts metadata/formats; it does not download media files to Vercel. Serverless runtimes have execution/time/storage limits. Platform access and formats can change; use only media you own or have permission to download.
- `yt-dlp` can be blocked by source platforms or become outdated. If it fails, update the dependency and redeploy.
- The catalog contains many near-duplicate workflow pages. For production SEO, consider `noindex` on variants until each has unique useful content; mass thin pages can be excluded from search engines.
- The downloader is intentionally restricted to an explicit platform allowlist. Never turn it into a generic URL fetcher without robust SSRF protections.
