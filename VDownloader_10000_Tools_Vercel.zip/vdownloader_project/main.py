import os, re, json, hashlib, secrets, string, ipaddress, socket
from urllib.parse import urlparse
from datetime import datetime, timezone
from flask import Flask, render_template, request, jsonify, Response, abort

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
BASE_URL = os.getenv('SITE_URL', 'https://vdownloder.xyz').rstrip('/')
SITE_NAME = 'VDownloader'

CATEGORIES = {
 'video': ('Video Tools', 'Download information, clip planning, subtitle and video utilities.'),
 'image': ('Image Tools', 'Resize, convert, compress and inspect images in your browser.'),
 'pdf': ('PDF Tools', 'Browser-based PDF helpers and document utilities.'),
 'text': ('Text Tools', 'Format, clean, compare and transform text.'),
 'seo': ('SEO Tools', 'Metadata, keyword, robots and sitemap utilities.'),
 'developer': ('Developer Tools', 'JSON, encoding, hashing and web-development helpers.'),
 'ai': ('AI Tools', 'AI prompt builders and productivity helpers. AI provider keys may be required for generation.'),
 'audio': ('Audio Tools', 'Audio workflow helpers and format information.'),
 'utility': ('Everyday Tools', 'Calculators, generators and small productivity tools.')
}

# Core tools are genuinely implemented in the browser. The 10,000-entry directory is
# generated from these tool families and search intents; it does not pretend that every
# catalog page is a separate AI service.
CORE_TOOLS = [
('word-counter','Word Counter','text','Count words, characters, sentences and paragraphs.','word-counter'),
('case-converter','Case Converter','text','Convert text to uppercase, lowercase, title case or sentence case.','case-converter'),
('remove-duplicate-lines','Remove Duplicate Lines','text','Remove repeated lines from text.','dedupe-lines'),
('sort-lines','Sort Lines','text','Sort lines alphabetically.','sort-lines'),
('text-reverser','Text Reverser','text','Reverse characters or word order.','reverse-text'),
('slug-generator','Slug Generator','seo','Create a clean URL slug from a title.','slug'),
('url-encoder-decoder','URL Encoder / Decoder','developer','Encode or decode URL components.','url-codec'),
('base64-encoder-decoder','Base64 Encoder / Decoder','developer','Encode text to Base64 or decode Base64 text.','base64'),
('json-formatter','JSON Formatter','developer','Validate, format and minify JSON.','json'),
('html-escape','HTML Escape / Unescape','developer','Escape HTML special characters or unescape entities.','html-escape'),
('url-parser','URL Parser','developer','Inspect protocol, host, path, query and fragment.','url-parser'),
('password-generator','Password Generator','utility','Generate a random password locally in your browser.','password'),
('uuid-generator','UUID Generator','developer','Generate a UUID v4 locally.','uuid'),
('hash-generator','Text Hash Generator','developer','Generate SHA-1, SHA-256 or SHA-512 hashes in your browser.','hash'),
('timestamp-converter','Unix Timestamp Converter','developer','Convert Unix timestamps to readable dates and back.','timestamp'),
('lorem-ipsum-generator','Lorem Ipsum Generator','text','Generate placeholder text.','lorem'),
('character-frequency','Character Frequency Counter','text','Count how often each character appears.','char-frequency'),
('line-counter','Line Counter','text','Count lines and blank lines.','line-counter'),
('text-diff','Text Difference Checker','text','Compare two text blocks line by line.','text-diff'),
('regex-tester','Regex Tester','developer','Test a regular expression against sample text.','regex'),
('markdown-preview','Markdown Preview Helper','text','Convert basic Markdown syntax into a safe preview.','markdown'),
('meta-tag-generator','Meta Tag Generator','seo','Generate title and description meta tags.','meta-tags'),
('robots-txt-generator','Robots.txt Generator','seo','Build a robots.txt file for your site.','robots'),
('sitemap-url-generator','Sitemap URL Generator','seo','Generate a basic XML sitemap from URL lines.','sitemap'),
('keyword-density-checker','Keyword Density Checker','seo','Estimate keyword frequency in text.','keyword-density'),
('reading-time-calculator','Reading Time Calculator','text','Estimate reading time from word count.','reading-time'),
('image-resizer','Image Resizer','image','Resize images locally with canvas.','image-resize'),
('image-format-converter','Image Format Converter','image','Convert an image to PNG, JPEG or WebP in your browser.','image-convert'),
('image-compressor','Image Compressor','image','Compress JPEG/WebP images locally in your browser.','image-compress'),
('image-to-base64','Image to Base64','image','Convert an image file to a Base64 data URL.','image-base64'),
('color-converter','Color Converter','utility','Convert HEX colors to RGB values.','color'),
('percentage-calculator','Percentage Calculator','utility','Calculate a percentage of a number.','percentage'),
('average-calculator','Average Calculator','utility','Calculate the average of numbers.','average'),
('unit-converter','Unit Converter','utility','Convert common length and weight units.','unit-convert'),
('csv-to-json','CSV to JSON Converter','developer','Convert simple CSV data into JSON.','csv-json'),
('json-to-csv','JSON to CSV Converter','developer','Convert an array of JSON objects into CSV.','json-csv'),
('html-minifier','HTML Whitespace Cleaner','developer','Remove excess whitespace from HTML source.','html-minify'),
('css-minifier','CSS Minifier','developer','Remove comments and unnecessary CSS whitespace.','css-minify'),
('javascript-minifier','JavaScript Whitespace Cleaner','developer','Remove comments and excess whitespace (not a full compiler).','js-minify'),
('word-frequency','Word Frequency Counter','text','Count the most frequent words in a text.','word-frequency'),
('email-validator','Email Format Validator','utility','Check the syntax of an email address locally.','email-validator'),
('phone-cleaner','Phone Number Cleaner','utility','Remove spaces and punctuation from a phone number.','phone-cleaner'),
('text-to-binary','Text to Binary Converter','developer','Convert text to UTF-8 binary and back.','binary'),
('number-base-converter','Number Base Converter','developer','Convert integers between common bases.','number-base'),
('random-number-generator','Random Number Generator','utility','Generate a random integer within a range.','random-number'),
('date-calculator','Date Difference Calculator','utility','Calculate the number of days between two dates.','date-diff'),
('video-downloader','Video Downloader','video','Fetch video title, thumbnail and available format metadata from supported platforms.','video-downloader'),
('video-aspect-ratio','Video Aspect Ratio Helper','video','Calculate common video aspect ratios and dimensions.','aspect-ratio'),
('clip-title-generator','Short Clip Title Helper','video','Create title ideas from a topic (template-based, no AI API).','clip-title'),
('video-description-helper','Video Description Helper','video','Build a reusable video description template.','video-description'),
('subtitle-cleaner','Subtitle Text Cleaner','video','Remove SRT/VTT timestamps and sequence numbers.','subtitle-cleaner'),
('ai-prompt-builder','AI Prompt Builder','ai','Build structured prompts for image, video and writing tasks.','prompt-builder'),
('youtube-tag-helper','Video Tag Helper','video','Turn a topic into suggested tags.','tags'),
('pdf-page-planner','PDF Page Planner','pdf','Estimate page ranges and split plans; actual PDF editing is not included.','pdf-planner'),
('audio-file-info','Audio Workflow Helper','audio','Explain common audio formats and prepare conversion notes.','audio-info'),
]

# Produce a stable 10,000-page searchable catalog from reusable tool families + intent variations.
# Pages beyond the core 55 are clearly identified as guides/variants, not falsely advertised as separate engines.
VARIANTS = ['online','free','fast','simple','advanced','for-beginners','for-creators','for-business','for-websites','for-social-media','for-youtube','for-tiktok','for-instagram','for-bloggers','for-marketing','for-developers','for-students','for-work','for-mobile','for-desktop','bulk','private','secure','quick','easy','professional','basic','pro','2026','step-by-step']
def slugify(s):
    s = s.lower().strip()
    s = re.sub(r'[^a-z0-9]+', '-', s)
    return re.sub(r'-+', '-', s).strip('-') or 'tool'

def build_catalog():
    catalog = {t[0]: {'slug':t[0], 'name':t[1], 'category':t[2], 'description':t[3], 'action':t[4], 'working':True} for t in CORE_TOOLS}
    base = list(catalog.values())
    i = 0
    # Add unique, clearly labeled guide/variant pages until 10,000 total entries.
    while len(catalog) < 10000:
        t = base[i % len(base)]
        v = VARIANTS[(i // len(base)) % len(VARIANTS)]
        suffix_num = (i // (len(base) * len(VARIANTS))) + 1
        slug = f"{t['slug']}-{v}" + (f"-{suffix_num}" if suffix_num > 1 else '')
        if slug not in catalog:
            catalog[slug] = {'slug':slug, 'name':f"{t['name']} {v.replace('-', ' ').title()}", 'category':t['category'], 'description':f"A focused guide and workflow for {t['name'].lower()} {v.replace('-', ' ')}. Core processing uses the same browser-based {t['name'].lower()} engine where applicable.", 'action':t['action'], 'working':True, 'variant':v, 'core_slug':t['slug']}
        i += 1
    return catalog
CATALOG = build_catalog()

@app.after_request
def security_headers(resp):
    resp.headers.setdefault('X-Content-Type-Options','nosniff')
    resp.headers.setdefault('X-Frame-Options','SAMEORIGIN')
    resp.headers.setdefault('Referrer-Policy','strict-origin-when-cross-origin')
    resp.headers.setdefault('Permissions-Policy','camera=(), microphone=(), geolocation=()')
    return resp

@app.route('/')
def home():
    q = request.args.get('q','').strip().lower()[:100]
    category = request.args.get('category','').strip().lower()
    tools = list(CATALOG.values())
    if category in CATEGORIES: tools = [t for t in tools if t['category'] == category]
    if q: tools = [t for t in tools if q in t['name'].lower() or q in t['description'].lower() or q in t['category']]
    tools.sort(key=lambda t: (not t.get('core_slug') and t['slug'] not in [x[0] for x in CORE_TOOLS], t['name']))
    return render_template('index.html', tools=tools[:120], total=len(CATALOG), categories=CATEGORIES, q=q, selected_category=category, core_count=len(CORE_TOOLS))

@app.route('/tool/<slug>')
def tool_page(slug):
    tool = CATALOG.get(slug)
    if not tool: abort(404)
    return render_template('tool.html', tool=tool, categories=CATEGORIES, site_url=BASE_URL)

@app.route('/api/tools')
def api_tools():
    q = request.args.get('q','').strip().lower()[:100]
    cat = request.args.get('category','').strip().lower()
    result = []
    for t in CATALOG.values():
        if cat and t['category'] != cat: continue
        if q and q not in t['name'].lower() and q not in t['description'].lower(): continue
        result.append({k:t[k] for k in ('slug','name','category','description','action','working')})
        if len(result) >= 100: break
    return jsonify({'total_catalog':len(CATALOG),'results':result})

@app.route('/download', methods=['POST'])
def download_info():
    data = request.get_json(silent=True) or request.form
    url = str(data.get('url','')).strip()
    if len(url) > 2048: return jsonify({'error':'URL bohat lamba hai.'}), 400
    parsed = urlparse(url)
    if parsed.scheme not in ('http','https') or not parsed.hostname:
        return jsonify({'error':'Valid http/https video URL dein.'}), 400
    host = parsed.hostname.lower().rstrip('.')
    allowed = ('youtube.com','youtu.be','youtube-nocookie.com','tiktok.com','instagram.com','facebook.com','fb.watch','x.com','twitter.com','vimeo.com','dailymotion.com','reddit.com','redd.it','twitch.tv','soundcloud.com','pinterest.com','snapchat.com','rumble.com')
    if not any(host == d or host.endswith('.'+d) for d in allowed):
        return jsonify({'error':'Is platform ko allow nahi kiya gaya. Supported platform ka URL use karein.'}), 400
    try:
        import yt_dlp
        opts = {'quiet':True,'no_warnings':True,'skip_download':True,'noplaylist':True,'socket_timeout':12,'extractor_retries':1,'ignoreerrors':False}
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
        if not info: return jsonify({'error':'Video metadata nahi mil saka.'}), 422
        formats = []
        for f in info.get('formats',[]):
            if f.get('url') and (f.get('vcodec') != 'none' or f.get('acodec') != 'none'):
                formats.append({'format_id':f.get('format_id'), 'ext':f.get('ext'), 'resolution':f.get('resolution') or f.get('format_note'), 'filesize':f.get('filesize') or f.get('filesize_approx'), 'has_video':f.get('vcodec') != 'none', 'has_audio':f.get('acodec') != 'none'})
        return jsonify({'title':info.get('title','Video'),'thumbnail':info.get('thumbnail'),'duration':info.get('duration'),'uploader':info.get('uploader'),'webpage_url':info.get('webpage_url',url),'formats':formats[:40], 'notice':'Direct media URLs and availability depend on the source platform. Use only content you own or have permission to download.'})
    except Exception as e:
        return jsonify({'error':'Video details hasil nahi ho sakin. URL, platform availability, ya yt-dlp update check karein.','detail':str(e)[:240]}), 422

@app.route('/robots.txt')
def robots():
    body = f"User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /download\nSitemap: {BASE_URL}/sitemap.xml\n"
    return Response(body, mimetype='text/plain')

@app.route('/sitemap.xml')
def sitemap():
    now = datetime.now(timezone.utc).date().isoformat()
    urls = [f'{BASE_URL}/', f'{BASE_URL}/about', f'{BASE_URL}/privacy', f'{BASE_URL}/terms', f'{BASE_URL}/contact']
    urls += [f"{BASE_URL}/tool/{t['slug']}" for t in CATALOG.values()]
    xml = ['<?xml version="1.0" encoding="UTF-8"?>','<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for u in urls:
        xml.append('<url><loc>'+u.replace('&','&amp;')+'</loc><lastmod>'+now+'</lastmod></url>')
    xml.append('</urlset>')
    return Response('\n'.join(xml), mimetype='application/xml')

PAGES = {
 'about':('About VDownloader','VDownloader provides browser-based productivity tools and video metadata utilities.'),
 'privacy':('Privacy Policy','Many tools process text and images locally in your browser. Video metadata requests are sent to the server and source platform.'),
 'terms':('Terms of Use','Use the service lawfully and only download content you own or have permission to use. Availability depends on third-party platforms.'),
 'contact':('Contact','For support, use the website contact email configured by the site owner.')
}
@app.route('/<page>')
def static_page(page):
    if page not in PAGES: abort(404)
    title, body = PAGES[page]
    return render_template('page.html', title=title, body=body, categories=CATEGORIES)

@app.errorhandler(404)
def not_found(_):
    return render_template('page.html', title='Page not found', body='The requested page could not be found.', categories=CATEGORIES), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.getenv('PORT','5000')), debug=False)
